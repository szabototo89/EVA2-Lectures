﻿using System;
using System.Collections.ObjectModel;
using System.Linq;

namespace ELTE.Trainings.Lecture10.TicTacToe.ViewModels
{
    public class GameTableViewModel : ViewModelBase
    {
        private int _Size;
        private int _CurrentPlayer;
        private bool _IsGameOver;

        public int Size
        {
            get { return _Size; }
            set
            {
                _Size = value;
                OnPropertyChanged(() => Size);
                Initialize();
            }
        }

        public int CurrentPlayer
        {
            get { return _CurrentPlayer; }
            set
            {
                _CurrentPlayer = value;
                OnPropertyChanged(() => CurrentPlayer);
                OnPropertyChanged(() => CurrentPlayerSymbol);
            }
        }

        public string CurrentPlayerSymbol
        {
            get
            {
                return CurrentPlayer == 0 ? "X" : "O";
            }
        }

        public GameTableViewModel(int size)
        {
            _Size = size;
            CurrentPlayer = 0;

            Initialize();
        }

        private GameTableViewModel Initialize()
        {
            if (Cells == null)
                Cells = new ObservableCollection<GameCellViewModel>();
            else
                Cells.Clear();

            for (var i = 0; i < Size; i++) {
                for (var j = 0; j < Size; j++) {
                    var cell = new GameCellViewModel(this, i, j);
                    Cells.Add(cell);
                }
            }

            return this;
        }

        private GameCellViewModel[][] GetGameTableMatrix()
        {
            return Cells.GroupBy(cell => cell.X)
                        .Select(group => group.Select(item => item)
                                              .ToArray())
                        .ToArray();
        }

        private void CheckCells(GameCellViewModel[] gameCells)
        {
            if (gameCells == null) throw new ArgumentNullException("gameCells");
            if (gameCells.All(cell => cell.Value == CurrentPlayerSymbol)) {
                IsGameOver = true;
                foreach (var cell in gameCells) {
                    cell.IsWinnerCell = true;
                }
            }
        }

        public GameTableViewModel NextRound()
        {
            var matrix = GetGameTableMatrix();

            for (int i = 0; i < Size; i++) {
                CheckCells(matrix[i]);  //sorok ellenőrzése
                CheckCells(matrix.Select(row => row[i]) //oszlopok ellenőrzése
                                 .ToArray());
            }

            //átlók ellenőrzése
            CheckCells(matrix.SelectMany(rows => rows)
                             .Where(cell => cell.X == cell.Y)
                             .ToArray());

            CheckCells(matrix.SelectMany(rows => rows)
                             .Where(cell => cell.X + cell.Y == Size - 1)
                             .ToArray());

            if (!IsGameOver)
                CurrentPlayer = (CurrentPlayer + 1) % 2;

            return this;
        }

        public bool IsGameOver
        {
            get { return _IsGameOver; }
            set
            {
                _IsGameOver = value;
                OnPropertyChanged(() => IsGameOver);
            }
        }

        public ObservableCollection<GameCellViewModel> Cells { get; protected set; }
    }
}
