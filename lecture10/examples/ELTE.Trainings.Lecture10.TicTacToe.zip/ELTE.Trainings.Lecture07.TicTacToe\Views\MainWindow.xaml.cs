﻿using System.Windows;
using ELTE.Trainings.Lecture10.TicTacToe.ViewModels;

namespace ELTE.Trainings.Lecture10.TicTacToe.Views
{
    /// <summary>
    /// Interaction logic for MainWindow.xaml
    /// </summary>
    public partial class MainWindow : Window
    {
        public MainWindow()
        {
            InitializeComponent();
            DataContext = new GameTableViewModel(5);
        }
    }
}
