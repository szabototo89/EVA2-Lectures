﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Windows.UI.Popups;
using ELTE.Trainings.Lecture10.TicTacToe.WinRT.ViewModels;

namespace ELTE.Trainings.Lecture10.TicTacToe.WinRT.Views
{
    public class WindowsMessageBoxService : IMessageBoxService
    {
        public void Show(string message)
        {
            new MessageDialog(message).ShowAsync();
        }
    }
}
