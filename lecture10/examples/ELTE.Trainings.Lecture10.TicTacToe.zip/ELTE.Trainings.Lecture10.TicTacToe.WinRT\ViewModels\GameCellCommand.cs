﻿using System;
using System.Windows.Input;

namespace ELTE.Trainings.Lecture10.TicTacToe.WinRT.ViewModels
{
    public class GameCellCommand : ICommand
    {
        public GameCellViewModel GameCell { get; protected set; }

        public GameCellCommand(GameCellViewModel gameCell)
        {
            if (gameCell == null) throw new ArgumentNullException("gameCell");
            GameCell = gameCell;
        }

        public bool CanExecute(object parameter)
        {
            return !GameCell.GameTable.IsGameOver && string.IsNullOrWhiteSpace(GameCell.Value);
        }

        public void Execute(object parameter)
        {
            var gameTable = GameCell.GameTable;
            if (gameTable.CurrentPlayer == 0)
                GameCell.Value = "X";
            else if (gameTable.CurrentPlayer == 1)
                GameCell.Value = "O";

            gameTable.NextRound();
        }

        public event EventHandler CanExecuteChanged;
    }
}
