﻿using System;

namespace ELTE.Trainings.Lecture10.TicTacToe.ViewModels
{
    public class GameCellViewModel : ViewModelBase
    {
        private string _Value;
        private int _X;
        private int _Y;
        private bool _IsWinnerCell;

        public GameTableViewModel GameTable { get; protected set; }

        public GameCellViewModel(GameTableViewModel gameTable, int x, int y, string value = null)
        {
            if (gameTable == null) throw new ArgumentNullException("gameTable");

            GameTable = gameTable;
            X = x;
            Y = y;
            Value = value;
            IsWinnerCell = false;
            ChangeValueCommand = new GameCellCommand(this);
        }

        public string Value
        {
            get { return _Value; }
            set
            {
                _Value = value;
                OnPropertyChanged(() => Value);
            }
        }

        public int X
        {
            get { return _X; }
            set
            {
                _X = value;
                OnPropertyChanged(() => X);
            }
        }

        public int Y
        {
            get { return _Y; }
            set
            {
                _Y = value;
                OnPropertyChanged(() => Y);
            }
        }

        public bool IsWinnerCell
        {
            get { return _IsWinnerCell; }
            set
            {
                _IsWinnerCell = value;
                OnPropertyChanged(() => IsWinnerCell);
            }
        }

        public GameCellCommand ChangeValueCommand { get; protected set; }
    }
}
