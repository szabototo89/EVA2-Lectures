﻿namespace ELTE.Trainings.Lecture10.TicTacToe.WinRT.ViewModels
{
    public interface IMessageBoxService
    {
        void Show(string message);
    }
}