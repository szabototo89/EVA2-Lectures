﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Windows.UI.Xaml;
using Windows.UI.Xaml.Controls;
using Windows.Web.Syndication;
using ELTE.Trainings.Lecture10.TicTacToe.WinRT.ViewModels;

namespace ELTE.Trainings.Lecture10.TicTacToe.WinRT.Views
{
    public class GameCellTemplateSelector : DataTemplateSelector
    {
        public DataTemplate FirstPlayerCellTemplate { get; set; }
        public DataTemplate SecondPlayerCellTemplate { get; set; }
        public DataTemplate EmptyCellTemplate { get; set; }

        protected override DataTemplate SelectTemplateCore(object item, DependencyObject container)
        {
            var value = item as string;

            switch (value)
            {
                case null:
                    return EmptyCellTemplate;
                case "X":
                    return FirstPlayerCellTemplate;
                case "O":
                    return SecondPlayerCellTemplate;
            }

            return null;
        }
    }
}
