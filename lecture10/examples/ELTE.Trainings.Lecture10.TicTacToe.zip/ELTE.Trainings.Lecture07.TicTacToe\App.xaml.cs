﻿using System.Windows;

namespace ELTE.Trainings.Lecture10.TicTacToe
{
    /// <summary>
    /// Interaction logic for App.xaml
    /// </summary>
    public partial class App : Application
    {
    }
}
