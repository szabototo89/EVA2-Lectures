﻿namespace SimpleCalculator.Log
{
    public interface ILogger
    {
        void Log(string message);
    }
}