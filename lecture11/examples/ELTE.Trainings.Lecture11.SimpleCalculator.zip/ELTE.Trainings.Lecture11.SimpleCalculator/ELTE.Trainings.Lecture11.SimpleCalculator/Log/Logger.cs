﻿using System;

namespace SimpleCalculator.Log
{
    public class Logger : ILogger
    {
        public void Log(string message)
        {
            Console.WriteLine("LOG: {0}", message);
        }
    }
}