﻿using System;
using System.Collections;
using System.Collections.Generic;
using SimpleCalculator.Log;
using SimpleCalculator.Operations;

namespace ELTE.Trainings.Lecture11.SimpleCalculator.Testing
{
    public class Calculator
    {
        public ILogger Logger { get; set; }
        public IEnumerable<int> Numbers { get; protected set; }

        public Calculator(ILogger logger, IEnumerable<int> numbers)
        {
            if (numbers == null) throw new ArgumentNullException("numbers");
            if (logger == null) throw new ArgumentNullException("logger");
            Logger = logger;
            Numbers = numbers;
        }

        public int Calculate(IOperation operation)
        {
            Logger.Log("Calculate operation ... ");

            if (operation == null)
                throw new ArgumentNullException("operation");

            operation.Reset();
            foreach (var number in Numbers) {
                operation.Calculate(number);
            }

            Logger.Log("Calculation is ready!");

            return operation.Result;
        }
    }
}