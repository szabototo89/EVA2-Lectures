﻿namespace SimpleCalculator.Operations
{
    public class Multiplication : IOperation
    {
        public void Reset()
        {
            Result = 1;
        }

        public void Calculate(int number)
        {
            Result = Result * number;
        }

        public int Result { get; protected set; }
    }
}