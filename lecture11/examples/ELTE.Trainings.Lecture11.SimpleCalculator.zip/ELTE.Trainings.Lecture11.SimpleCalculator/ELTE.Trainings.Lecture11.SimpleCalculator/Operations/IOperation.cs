﻿namespace SimpleCalculator.Operations
{
    public interface IOperation
    {
        void Reset();
        void Calculate(int number);
        int Result { get; }
    }
}