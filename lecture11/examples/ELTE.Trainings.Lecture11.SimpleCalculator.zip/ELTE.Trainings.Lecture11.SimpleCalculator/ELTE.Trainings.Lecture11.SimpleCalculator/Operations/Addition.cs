﻿namespace SimpleCalculator.Operations
{
    public class Addition : IOperation
    {
        public Addition()
        {
            Reset();
        }

        public void Reset()
        {
            Result = 0;
        }

        public void Calculate(int number)
        {
            Result += number;
        }

        public int Result { get; protected set; }
    }
}