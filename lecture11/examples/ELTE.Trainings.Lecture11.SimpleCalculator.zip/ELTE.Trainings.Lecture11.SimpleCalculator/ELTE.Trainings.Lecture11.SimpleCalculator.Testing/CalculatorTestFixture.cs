﻿using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.Linq;
using System.Runtime.InteropServices;
using System.Text;
using System.Threading.Tasks;
using Moq;
using NUnit.Framework;
using SimpleCalculator.Log;
using SimpleCalculator.Operations;

namespace ELTE.Trainings.Lecture11.SimpleCalculator.Testing
{
    [TestFixture]
    class CalculatorTestFixture
    {
        protected ILogger Logger { get; set; }

        [SetUp]
        public void Setup()
        {
            Logger = new Logger();
        }

        [Test]
        [ExpectedException(typeof(ArgumentNullException))]
        public void TestCalculateInitalizeWithNullArray()
        {
            // GIVEN
            var underTest = new Calculator(Logger, null);
            // WHERE
            // THEN
        }

        [Test]
        [ExpectedException(typeof(ArgumentNullException))]
        public void TestCalculateInitalizeWithNullLogger()
        {
            // GIVEN
            var underTest = new Calculator(null, null);
            // WHERE
            // THEN
        }

        [TestCase(new[] { 1, 2, 3, 4 })]
        [TestCase(new[] { 5, 6, 7, 8 })]
        public void TestCalculateShouldReturnSumOfNumbers(int[] numbers)
        {
            // GIVEN
            var underTest = new Calculator(Logger, numbers);
            // WHERE
            var result = underTest.Calculate(new Addition());
            // THEN
            Assert.AreEqual(numbers.Sum(), result);
        }

        [TestCase(new[] { 1, 2, 3 })]
        [TestCase(new[] { 9, 8, 7 })]
        public void TestCalculateShouldReturnMultiplicationOfNumbers(int[] numbers)
        {
            // GIVEN
            var underTest = new Calculator(Logger, numbers);
            // WHERE
            var result = underTest.Calculate(new Multiplication());
            // THEN
            Assert.AreEqual(numbers.Aggregate(1, (x, y) => x * y), result);
        }

        [Test]
        [ExpectedException(typeof(ArgumentNullException))]
        public void TestCalculateWithNullOperationParameter()
        {
            // GIVEN
            var underTest = new Calculator(Logger, new[] { 1, 2, 3 });
            // WHERE
            var result = underTest.Calculate(null);
            // THEN
            Assert.AreEqual(result, 0);
        }

        [Test(Description = "Calculate method should call Log method exactly twice")]
        public void TestCalculateShouldLogTwice()
        {
            // GIVEN
            var operation = new Mock<IOperation>();
            var logger = new Mock<ILogger>();

            var underTest = new Calculator(logger.Object, new[] { 1, 2, 3 });
            // WHERE
            underTest.Calculate(operation.Object);
            // THEN
            logger.Verify(mock => mock.Log(It.IsAny<string>()), Times.Exactly(2));
        }
    }
}
