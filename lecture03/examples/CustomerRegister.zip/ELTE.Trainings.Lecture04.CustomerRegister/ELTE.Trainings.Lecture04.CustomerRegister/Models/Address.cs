﻿namespace ELTE.Trainings.Lecture04.CustomerRegister.Models
{
	public class Address
	{
		public string City { get; set; }
		public string Country { get; set; }
		public string Postcode { get; set; }
		public string StreetAddress { get; set; }
	}
}