﻿namespace ELTE.Trainings.Lecture04.CustomerRegister.Models
{
	public enum EmployeeType
	{
		Intern,
		Graduated,
		Manager,
		VicePresident,
		Contractor
	}
}