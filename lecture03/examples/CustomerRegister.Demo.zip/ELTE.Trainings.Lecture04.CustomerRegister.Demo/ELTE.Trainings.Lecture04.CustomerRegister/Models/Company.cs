﻿namespace ELTE.Trainings.Lecture04.CustomerRegister.Models
{
	public class Company
	{
		public string Name { get; set; }
		public Address Address { get; set; }
	}
}