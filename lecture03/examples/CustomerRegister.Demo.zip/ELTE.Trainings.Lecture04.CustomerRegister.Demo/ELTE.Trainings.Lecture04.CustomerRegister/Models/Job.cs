﻿namespace ELTE.Trainings.Lecture04.CustomerRegister.Models
{
	public class Job
	{
		
	}
}